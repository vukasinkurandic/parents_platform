from django.contrib import admin
from . models import Connection

admin.site.register(Connection)
