from django.contrib import admin
from .models import Commentary, Rate, Report

admin.site.register(Commentary)
admin.site.register(Rate)
admin.site.register(Report)
