from django.apps import AppConfig


class ErrorHandlersConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'error_handlers'
